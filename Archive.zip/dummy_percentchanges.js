{
    "percentchanges": [
        {
            "id": 1,
            "timeaxis": "01/01/2013 12:00",
			"mylikes": 3.9,
			"mycomments": 1.8,
			"cmplikes": 1.9,
			"cmpcomments": 1.7
        },
		{
            "id": 2,
            "timeaxis": "01/01/2013 12:00",
			"mylikes": 3.9,
			"mycomments": 1.8,
			"cmplikes": 1.9,
			"cmpcomments": 1.7
        },
		{
            "id": 3,
            "timeaxis": "01/01/2013 12:00",
			"mylikes": 3.9,
			"mycomments": 1.8,
			"cmplikes": 1.9,
			"cmpcomments": 1.7
        },
		{
            "id": 4,
            "timeaxis": "01/01/2013 12:00",
			"mylikes": 3.9,
			"mycomments": 1.8,
			"cmplikes": 1.9,
			"cmpcomments": 1.7
        },
		{
            "id": 5,
            "timeaxis": "01/01/2013 12:00",
			"mylikes": 3.9,
			"mycomments": 1.8,
			"cmplikes": 1.9,
			"cmpcomments": 1.7
        },
		{
            "id": 6,
            "timeaxis": "01/01/2013 12:00",
			"mylikes": 3.9,
			"mycomments": 1.8,
			"cmplikes": 1.9,
			"cmpcomments": 1.7
        },
		{
            "id": 7,
            "timeaxis": "01/01/2013 12:00",
			"mylikes": 3.9,
			"mycomments": 1.8,
			"cmplikes": 1.9,
			"cmpcomments": 1.7
        },
		{
            "id": 8,
            "timeaxis": "01/01/2013 12:00",
			"mylikes": 3.9,
			"mycomments": 1.8,
			"cmplikes": 1.9,
			"cmpcomments": 1.7
        },
		{
            "id": 9,
            "timeaxis": "01/01/2013 12:00",
			"mylikes": 3.9,
			"mycomments": 1.8,
			"cmplikes": 1.9,
			"cmpcomments": 1.7
        },
		{
            "id": 10,
            "timeaxis": "01/01/2013 12:00",
			"mylikes": 3.9,
			"mycomments": 1.8,
			"cmplikes": 1.9,
			"cmpcomments": 1.7
        },
		{
            "id": 11,
            "timeaxis": "01/01/2013 12:00",
			"mylikes": 3.9,
			"mycomments": 1.8,
			"cmplikes": 1.9,
			"cmpcomments": 1.7
        },
		{
            "id": 12,
            "timeaxis": "01/01/2013 12:00",
			"mylikes": 3.9,
			"mycomments": 1.8,
			"cmplikes": 1.9,
			"cmpcomments": 1.7
        }
    ]
}