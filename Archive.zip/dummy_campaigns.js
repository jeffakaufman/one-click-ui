{
    "campaigns": [
        {
            "id": 1,
            "name": "Contest Modal",
			"description": "Enter to win a trip for 2 to Paris! Post a comment for a chance to win.",
			"image": "images/gap-model-contest-for-babies-and-kids.jpg",
			"status": "1",
			"userengagement": "",
			"startdate": "2013/08/15",
			"enddate": "",
			"budget": "",
			"fblikes": "67",
			"fbposts": "0",
			"fbpage": "Coca-Cola"
        },
		{
            "id": 2,
            "name": "Contest Submission",
			"description": "",
			"image": "",
			"status": "",
			"userengagement": "",
			"startdate": "",
			"enddate": "",
			"budget": "",
			"fblikes": "102",
			"fbposts": "",
			"fbpage": "Coca-Cola"
        },
		{
            "id": 3,
            "name": "Contest Entry",
			"description": "",
			"image": "",
			"status": "",
			"userengagement": "",
			"startdate": "",
			"enddate": "",
			"budget": "",
			"fblikes": "13",
			"fbposts": "",
			"fbpage": "Coca-Cola"
        }
    ]
}